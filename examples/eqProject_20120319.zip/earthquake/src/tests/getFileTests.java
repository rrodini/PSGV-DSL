package tests;

import junit.framework.TestCase;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import pennstate.dsl.earthquake.*;


public class getFileTests extends TestCase {
	
	public void testFile(){

		BufferedReader dataHour = Earthquake.getEqData("hour");
		try {
		  assertTrue(dataHour.readLine().contains("Magnitude"));
		} catch (Exception e) {e.printStackTrace();}

		BufferedReader dataDay = Earthquake.getEqData("day");
		try {
		  assertTrue(dataDay.readLine().contains("Magnitude"));
		} catch (Exception e) {e.printStackTrace();}

		BufferedReader dataWeek = Earthquake.getEqData("week");
		try {
		  assertTrue(dataWeek.readLine().contains("Magnitude"));
		} catch (Exception e) {e.printStackTrace();}

		// test parser
		Parser p = new Parser();
		ArrayList<EarthquakeEvent> al = p.parseEqData(dataDay);
		assertTrue(al.size()>0);
		System.out.println(al.get(1).toString());
		
		// test comparator
		Collections.sort(al, new EqMagComparator());
		Iterator<EarthquakeEvent> eqItr = al.iterator();
		while (eqItr.hasNext()) {
			EarthquakeEvent eqEv = (EarthquakeEvent) eqItr.next();
			  System.out.println(eqEv.getMag() + " | " + eqEv.getRegion());	
		}
		
	}
}
