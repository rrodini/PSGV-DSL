package pennstate.dsl.earthquake;
import java.io.*;
import java.net.*;
import java.util.*;

public class Earthquake {
   static BufferedReader brData;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File csv = new File(args[0]);
		Parser p = new Parser();
		
		// Parse the input file
		Hashtable<String, String> input = p.parseInputFile(csv);
		
		// First action: get data based upon duration
		BufferedReader brData = getEqData(input.get("timespan"));
		ArrayList<EarthquakeEvent> al = p.parseEqData(brData);
		
		// Second action: sort data
		// data is initially sorted by time;
		// sort by magnitude if grammar says to
	    System.out.println( input.get("sortby"));	
		if (input.get("sortby").equals("magnitude")) { Collections.sort(al, new EqMagComparator()); }
		
		// Third action: generate output
		System.out.println(generateOuput(input.get("output"), al));

	}
	
	static public BufferedReader getEqData(String timespan) {
		try {
			
			 URL urlEarthquakeData = new URL(createURL(timespan));
		     URLConnection uc = urlEarthquakeData.openConnection();
		     brData = new BufferedReader(new InputStreamReader(uc.getInputStream()));
		} catch (Exception e) {e.printStackTrace();}
		return brData;
	}
	
	static private String createURL(String duration) {
		String url;
		
		if (duration.equals("hour")) { url = "http://earthquake.usgs.gov/earthquakes/catalogs/eqs1hour-M0.txt"; }
		else if (duration.equals("day")) { url = "http://earthquake.usgs.gov/earthquakes/catalogs/eqs1day-M0.txt"; }
		else if (duration.equals("week")){ url = "http://earthquake.usgs.gov/earthquakes/catalogs/eqs7day-M2.5.txt"; }
		else { url = "http://earthquake.usgs.gov/earthquakes/catalogs/eqs1day-M0.txt"; }
		
		System.out.println(url);
		return url;	
	}
	
	static private String generateOuput(String sOutputCols, ArrayList<EarthquakeEvent> al) {
		String sOut = new String();
		Hashtable<Integer, String> outFormat = new Hashtable<Integer, String>();
		
        String[] st = sOutputCols.split(",");
        int tokenNumber = 0;
        for(String t : st) {
            // create a hashtable to carry the column names
            if(t.equals("date-time")){ outFormat.put(tokenNumber, "date-time"); }
            else if(t.equals("lat-long")){ outFormat.put(tokenNumber, "lat-long"); }
            else if(t.equals("mag")){ outFormat.put(tokenNumber, "mag"); }
            else if(t.equals("depth")){ outFormat.put(tokenNumber, "depth"); }
            else if(t.equals("region")){ outFormat.put(tokenNumber, "region"); }
            else System.out.println("Unknown token in line");
            tokenNumber++;
        }
        
        // load the output string
		Iterator<EarthquakeEvent> eqItr = al.iterator();
		while (eqItr.hasNext()) {
			EarthquakeEvent eqEv = (EarthquakeEvent) eqItr.next();
			for(int i = 0; i < outFormat.size(); i++ ){
				if( outFormat.get(i).equals("date-time")) { 
					sOut = sOut + eqEv.getDatetime() + " ";
					continue;
				}
				if( outFormat.get(i).equals("lat-long")) { 
					sOut = sOut + eqEv.getLat() + ":" + eqEv.getLon() + " ";
					continue;
				}
				if( outFormat.get(i).equals("mag")) { 
					sOut = sOut + eqEv.getMag() + " ";
					continue;
				}
				if( outFormat.get(i).equals("depth")) { 
					sOut = sOut + eqEv.getDepth() + " ";
					continue;
				}
				if( outFormat.get(i).equals("region")) { 
					sOut = sOut + eqEv.getRegion() + " ";
					continue;
				}
			}
			// start a new line
			sOut = sOut + "\n";
		}
		return sOut;
	}

}
