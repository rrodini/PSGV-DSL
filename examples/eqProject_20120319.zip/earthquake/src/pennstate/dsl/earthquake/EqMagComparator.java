package pennstate.dsl.earthquake;

import java.util.Comparator;

public class EqMagComparator implements Comparator<EarthquakeEvent> {
	public int compare (EarthquakeEvent eq1, EarthquakeEvent eq2) {
		Float fEq1 = new Float(eq1.getMag());
		Float fEq2 = new Float(eq2.getMag());
		return fEq1.compareTo(fEq2);
	}

}
