package pennstate.dsl.earthquake;

import java.util.*;
import java.io.*;


public class Parser {

	public Hashtable<String, String> parseInputFile(File in){
		Hashtable<String, String> ht = new Hashtable<String, String>();

		try {
	        //create BufferedReader to read csv file
	        BufferedReader br = new BufferedReader( new FileReader(in));
	        String strLine = "";

	       
	        //read comma separated file line by line
	        while( (strLine = br.readLine()) != null)
	        {
	          String[] st = strLine.split(":");
	          // get the key
	          String key = st[0];
	          // get the value
	          String value = st[1];
	          // add it to the hashtable
	          ht.put(key, value);
             }
		}
		catch(Exception e) {
		  System.out.println("Exception while reading input file: " + e);                  
		}
		
		return ht;
	}

	public ArrayList<EarthquakeEvent> parseEqData(BufferedReader data){
		ArrayList<EarthquakeEvent> al = new ArrayList<EarthquakeEvent>();

		try {
	        //create BufferedReader to read csv file
	        String strLine = "";
	        int lineNumber = 0;
	       
	        //read comma separated file line by line
	        while( (strLine = data.readLine()) != null)
	        {
	          lineNumber++;
	          // First line is column headers...
	          if (lineNumber == 1) { continue; }
	          // create an earthquake event
	          EarthquakeEvent eqev = createEarthquakeEvent(strLine);
	          // add it to the arraylist
	          al.add(eqev);
             }
		}
		catch(Exception e) {
		  System.out.println("Exception while reading csv file: " + e);                  
		}
		
		return al;
	}
	
	
	private EarthquakeEvent createEarthquakeEvent(String line) {
        // create EarthquakeEvent to keep the data
		EarthquakeEvent ee = new EarthquakeEvent();
        // split on the comma only if that comma has zero, or an even number of quotes in ahead of it...
        String[] st = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        int tokenNumber = 0;
        for(String t : st) {
            //display csv values
            tokenNumber++;
            if(tokenNumber==1){ ee.setSrc(t);}
            else if(tokenNumber==2){ ee.setEqid(t);}
            else if(tokenNumber==3){ ee.setVersion(t);}
            else if(tokenNumber==4){ ee.setDatetime(t);}
            else if(tokenNumber==5){ ee.setLat(t);}
            else if(tokenNumber==6){ ee.setLon(t);}
            else if(tokenNumber==7){ ee.setMag(t);}
            else if(tokenNumber==8){ ee.setDepth(t);}
            else if(tokenNumber==9){ ee.setNst(t);}
            else if(tokenNumber==10){ ee.setRegion(t);}
            else System.out.println("Unknown token in line");                  
        }
		return ee;
	}
}
