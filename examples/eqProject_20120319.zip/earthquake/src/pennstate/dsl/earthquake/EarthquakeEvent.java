package pennstate.dsl.earthquake;

public class EarthquakeEvent {
	String src;
	String eqid;
	String version;
	String datetime;
	String lat;
	String lon;
	String mag;
	String depth;
	String nst;
	String region;

	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
	public String getEqid() {
		return eqid;
	}
	public void setEqid(String eqid) {
		this.eqid = eqid;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLon() {
		return lon;
	}
	public void setLon(String lon) {
		this.lon = lon;
	}
	public String getMag() {
		return mag;
	}
	public void setMag(String mag) {
		this.mag = mag;
	}
	public String getDepth() {
		return depth;
	}
	public void setDepth(String depth) {
		this.depth = depth;
	}
	public String getNst() {
		return nst;
	}
	public void setNst(String nst) {
		this.nst = nst;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String toString(){
		String s = "src: " + src +
                   "|eqid: " + eqid +
                   "|ver: " + version +
                   "|datetime: " + datetime +
                   "|lat: " + lat +
                   "|lon: " + lon +
                   "|mag: " + mag +
                   "|depth: " + depth +
                   "|nst: " + nst +
                   "|region: " + region;
		return s;
	}
}
